# Подключение Telegram-бота к порталу Justice Faite

Сайт создаёт ссылки Telegram вида `https://t.me/<bot_username>?start=<payload>`. Telegram отправляет в личную переписку `/start <payload>`. Он не исполняет из URL произвольные slash-команды, поэтому текущий `/start` в боте должен распознать переданный параметр.

В текущем коде репозитория `Larkins2007/anonymous-flood-bot` (ветка `main`, файл `bot.py`) уже есть один обработчик `CommandStart`. Не добавляй второй `CommandStart`-handler: дополни существующий `async def start(...)`.

## Готовый фрагмент для `bot.py`

Найди внутри `start()` участок после специальных обработчиков `spy` и `help`, но до обычного блока: `if not await cmdcfg.gate(message, "start"):`. Вставь туда следующий код:

```python
    start_match = re.match(
        r"^/start(?:@[A-Za-z0-9_]+)?(?:\s+([A-Za-z0-9_-]{1,64}))?\s*$",
        text,
        flags=re.IGNORECASE,
    )
    site_payload = (start_match.group(1) or "").casefold() if start_match else ""

    if site_payload in {"rest", "tokens", "anonymous", "anon"}:
        if not await cmdcfg.gate(message, "start"):
            return
        await state.clear()
        register_user(message.from_user)
        await delete_user_message(message)

        if is_blocked(message.from_user.id):
            await message.answer(
                f"{title('Доступ ограничен')}\n\n"
                f"{bullet('Для вашего аккаунта отправка сообщений отключена.')}"
            )
            return

        if site_payload == "rest":
            await message.answer(
                f"{title('Самостоятельный рест')}\n\n"
                f"{bullet('Открой основной чат Justice Faite и отправь команду: взять рест на 7 дней.')}\n"
                f"{bullet('Можно указать дату окончания: взять рест до 15.11.')}\n"
                f"{bullet('Самостоятельный рест ограничен 14 днями.')}\n\n"
                f"{divider()}\n"
                "Если удобнее, обратись в личные сообщения к владельцу или совладельцу и укажи роль и точные даты отсутствия."
            )
            return

        if site_payload == "tokens":
            await message.answer(
                f"{title('Жетоны Justice Faite')}\n\n"
                f"{bullet('Первый кошелёк получает стартовый бонус 30 жетонов.')}\n"
                f"{bullet('Команда «Ферма» приносит от 5 до 50 жетонов раз в 4 часа.')}\n"
                f"{bullet('«Баланс» или «Кошелёк» показывают остаток.')}\n"
                f"{bullet('«Магазин» показывает предметы и цены. Покупка: «Купить название».')}\n"
                f"{bullet('«Инвентарь», «Надеть название» и «Снять слот» управляют купленными предметами.')}\n\n"
                f"{divider()}\n"
                "Команды экономики нужно отправлять в основном чате Justice Faite. Здесь открыт справочник, а не отдельный кошелёк."
            )
            return

        # Reuse the existing anonymous-feedback FSM and submission logic.
        anonymous_message = message.model_copy(update={"text": "/anon", "entities": []})
        await anon_command(anonymous_message, state)
        return
```

Этот фрагмент использует уже существующие `title`, `bullet`, `divider`, `register_user`, `delete_user_message`, `is_blocked` и `anon_command` из `bot.py`. Не создавай дублирующие обработчики, состояния или таблицы. После вставки проверь `python -m py_compile bot.py` и тестовую отправку каждого из трёх deep-link-параметров.

## Что делает каждая ссылка

- `start=rest`: открывает личку и показывает команду самостоятельного реста. Саму команду `взять рест на 7 дней` нужно отправить в основном групповом чате: существующий обработчик `rest_self` принимает её только там. Самостоятельный рест ограничен 14 днями. Также участник может обратиться к владельцу или совладельцу.
- `start=tokens`: открывает личку с подсказкой по экономике. Реальные команды `Баланс`, `Ферма`, `Магазин`, `Купить название`, `Инвентарь`, `Надеть название` и `Снять слот` отправляются в основном групповом чате, поскольку модуль экономики зарегистрирован для групп.
- `start=anonymous`: повторно использует текущую личную форму `anon_command` и переводит пользователя в существующее состояние ожидания текста.

## Важное уведомление об анонимной связи

В текущем коде форма `/anon` не обеспечивает анонимность от администрации: обработчик передаёт вместе с текстом имя, username и Telegram ID отправителя. Сайт и бот должны прямо сообщать об этом участникам. Не называй функцию полностью анонимной.

## Синхронизация количества участников

Сайт поддерживает endpoint `POST /api/bot/stats`. Токен хранится только на сервере сайта и в переменных окружения бота. Добавь в конфигурацию бота:

- `JF_SITE_URL` — полный URL портала, например `https://example.onrender.com`;
- `BOT_SYNC_TOKEN` — то же секретное значение, которое задано у сайта.

Пример отправки:

```python
import os
import aiohttp

async def publish_member_count(member_count: int) -> None:
    site_url = os.environ["JF_SITE_URL"].rstrip("/")
    token = os.environ["BOT_SYNC_TOKEN"]
    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{site_url}/api/bot/stats",
            headers={"Authorization": f"Bearer {token}"},
            json={"memberCount": int(member_count)},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as response:
            response.raise_for_status()
```

Публикуй только фактическое значение, полученное от Telegram Bot API или из проверенного списка участников. Не подставляй предположительное число.
